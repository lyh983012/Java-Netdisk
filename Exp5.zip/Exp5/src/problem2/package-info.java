/**
 * 
 */
/**
 * @author lyh
 *这个实验在Deal 类中直接做

 */
package problem2;