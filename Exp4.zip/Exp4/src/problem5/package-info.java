/**
 * 
 */
/**
 * @author lyh
 *在项目 Exp4 中新建名为“
 *problem5”的包，在 problem5 包下
 *创建 StringEncryptor.java。 创
 *建方法 encode1,decode1,encode2,
 *decode2，实现
 题目要求。自己在 mai
 n 里写测试方法，
 以 验证正确性。
 */
package problem5;