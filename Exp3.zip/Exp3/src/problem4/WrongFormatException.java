package problem4;

public class WrongFormatException extends Exception {
	public String inform="Wrong Format";
}
