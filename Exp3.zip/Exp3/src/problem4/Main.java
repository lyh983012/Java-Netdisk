package problem4;

import java.util.Scanner;

import problem2.Calculator_1;
import problem2.Calculator_2;

public class Main {
	public static void main(String arg[]) throws Exception {

	ChangeCalculator randomom = new ChangeCalculator();
	randomom.findCoin();
	}
	
}
