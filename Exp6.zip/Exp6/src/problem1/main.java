package problem1;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;

public class main {
	
public static void main(String args[]) throws FileNotFoundException {
    String fileName = "Hello.txt";
	BufferedReader ha= new BufferedReader(new FileReader(fileName));
}
}