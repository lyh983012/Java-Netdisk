/**
 * 
 */
/**
 * @author lyh
 * 所有的项目分写在个个java文件中，在_main类中统一调用方法接口
 *
 */
package problem4;