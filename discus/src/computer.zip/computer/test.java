package computer;

public class test {

	public static void main (String arg[]) {
		//UseCompute<Double> use =new UseCompute<Double>();//需要先给予一个类型
		//use.start_calculation();
		
		UseCompute<Double> use2 =new UseCompute<Double>();
		use2.start_calculation();
	}
}
