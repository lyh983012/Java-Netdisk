package problem4;

public class InputOutOfRangeException  extends  Exception{
	public String inform="Input out of range";

}
