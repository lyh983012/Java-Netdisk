package problem3;

import java.util.ArrayList;
import java.util.Random;

public class exp3 {

	static public void main(String args[]) {
		vecto throbject=new vecto(13,20);
		cosumer con= new cosumer(throbject);
		producer pro= new producer(throbject);
		con.start();
		pro.start();
	}
}
 
class producer extends Thread {

	producer(vecto stoe){
		super(stoe);
		storage=stoe;
	}
	vecto storage;
	@Override
	public void run() {
		while(true) {
			try {	
				System.out.println("produced and the remain is "+storage.slist.size());
				produce();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			System.out.println("produced and the remain is "+storage.slist.size());
		}
	}
	
	public synchronized void produce() throws InterruptedException {
		for(int i=0;i<storage.pr;i++) {
			Random ran=new Random();
			storage.slist.add("get:  "+ran.nextInt()+"---");
		}
		this.notify();
		this.wait();
	};
	
}

class cosumer extends Thread {
	vecto storage;
	cosumer(vecto stoe){
		super(stoe);
		storage=stoe;
	}
	@Override
	public void run() {
		while(true) {
		try {
			System.out.println("consumed and the remain is "+storage.slist.size());
			consume();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	}
	
	public synchronized void consume() throws InterruptedException {
		for(int i=0;i<storage.co;i++) {
			if(storage.slist.size()<=0) {
				this.notify();
				this.wait();
			}
			System.out.println(storage.slist.get(storage.slist.size()-1));
			storage.slist.remove(storage.slist.size()-1);
		}
	};
}

class vecto implements Runnable{

	ArrayList<String> slist;
	boolean available;
	int co,pr;
	public vecto(int n,int m) {
		co=n;
		pr=m;
		available=false;
		slist=new ArrayList<String>();
	}
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}
}
