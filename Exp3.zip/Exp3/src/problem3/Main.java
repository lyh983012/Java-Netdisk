package problem3;

import java.util.Scanner;

import problem2.Calculator_1;
import problem2.Calculator_2;

public class Main {
	public static void main(String arg[]) throws Exception {

	RandomGenerator randomom = new RandomGenerator();
	randomom.generator(20);

	
	}
	
}
